#ifdef _MSC_VER
#include <msinttypes/inttypes.h>
#else
#include <inttypes.h>
#endif
