MVMObject * MVM_io_socket_create(MVMThreadContext *tc, MVMint64 listen);
MVMString * MVM_io_get_hostname(MVMThreadContext *tc);
