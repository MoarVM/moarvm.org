void MVM_spesh_deopt(MVMThreadContext *tc);
