64-bit version of TinyMT[1] as used by MoarVM[2]

Original code published by

    Mutsuo Saito, (saito@math.sci.hiroshima-u.ac.jp) Hiroshima University
    Makoto Matsumoto, The University of Tokyo 

under the 3-clause BSD license.

[1] http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/TINYMT/
[2] https://github.com/MoarVM/MoarVM/
