void MVM_jit_log(MVMThreadContext *tc, const char *fmt, ...);
void MVM_jit_log_bytecode(MVMThreadContext *tc, MVMJitCode *code);
