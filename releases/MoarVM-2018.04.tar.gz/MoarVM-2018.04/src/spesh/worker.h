void MVM_spesh_worker_setup(MVMThreadContext *tc);
