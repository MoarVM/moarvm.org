MVMuint32 MVM_spesh_threshold(MVMThreadContext *tc, MVMStaticFrame *sf);
