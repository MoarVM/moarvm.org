MVMObject * MVM_io_file_watch(MVMThreadContext *tc, MVMObject *queue,
    MVMObject *schedulee, MVMString *path, MVMObject *async_type);
