char * MVM_spesh_dump(MVMThreadContext *tc, MVMSpeshGraph *g);
