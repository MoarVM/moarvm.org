This tests arm/thumb interwork.
Run build.sh from top-level build directory.

1. dyncall is compiled as default using Makefile-default.config
2. tests are compiled with -mthumb using Makefile-thumb.config


