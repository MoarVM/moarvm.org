void MVM_6model_bootstrap(MVMThreadContext *tc);
