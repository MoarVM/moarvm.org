## Current Docs

### [Strings](strings.asciidoc)

### [Collation](collation.asciidoc)

## Historical Design Docs

These documents are mostly of historical interest for the heavy design phases
of MoarVM, but may also be useful for understanding its current operation.
