#!/bin/sh
for i in $* ; do
  $i/$i
done

