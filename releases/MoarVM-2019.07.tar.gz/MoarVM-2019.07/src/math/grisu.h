#ifndef MATH_GRISU_H
#define MATH_GRISU_H

int dtoa_grisu3(double v, char *dst, int size);

#endif
