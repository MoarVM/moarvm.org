/* The number of runs we do to log what we see. */
#define MVM_SPESH_LOG_RUNS  4
