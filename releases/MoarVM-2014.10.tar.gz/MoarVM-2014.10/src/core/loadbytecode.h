void MVM_load_bytecode(MVMThreadContext *tc, MVMString *filename);
