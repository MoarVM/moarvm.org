void *memmem_uint32(const void *h0, size_t k, const void *n0, size_t l);
